# ComidaSemanal

Web de menú semanal con panel de administración.

## Stack
- **Frontend:** HTML/CSS/JS vanilla
- **Backend:** Node.js + Express
- **Datos:** JSON file (persistido en Docker volume)
- **Deploy:** Docker Compose → Dokploy

## Setup rápido

```bash
# 1. Clona el repo
git clone https://github.com/asogomez22/ComidaSemanal.git
cd ComidaSemanal

# 2. Cambia la contraseña en docker-compose.yml
#    ADMIN_PASSWORD=tu-contraseña-segura

# 3. Levanta
docker compose up -d
```

## URLs
- `/` → Web principal (menú del día + semana)
- `/admin.html` → Panel de administración (requiere contraseña)
- `/api/meals` → API JSON (pública, lectura)

## Variables de entorno
| Variable | Default | Descripción |
|---|---|---|
| `ADMIN_PASSWORD` | `admin123` | Contraseña del panel admin |
| `PORT` | `3000` | Puerto del servidor |

## Dokploy
1. New Application → Docker Compose
2. Conectar repo GitHub
3. Cambiar `meal.tudominio.com` por tu dominio
4. Configurar `ADMIN_PASSWORD` en las env vars de Dokploy
5. Deploy
